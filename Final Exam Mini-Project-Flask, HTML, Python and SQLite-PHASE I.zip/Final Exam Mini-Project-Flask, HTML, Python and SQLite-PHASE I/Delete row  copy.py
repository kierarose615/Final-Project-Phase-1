import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()

cursor.execute("DELETE FROM celebs")   # clears the table
conn.commit()
conn.close()