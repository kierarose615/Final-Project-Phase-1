
import sqlite3



conn = sqlite3.connect("celebrities.db copy")

cursor = conn.cursor()


conn.close()
