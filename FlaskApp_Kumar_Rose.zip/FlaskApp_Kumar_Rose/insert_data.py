import sqlite3
conn = sqlite3.connect("celebrities.db")
cursor = conn.cursor()




sql = "INSERT INTO celebs values(?,?,?,?,?,?,?)"
data = (1, "Angelina", "Jolie", 40, "angelina@hollywood.us", "https://s3.amazonaws.com/isat3402021/aj.jpg", "Angelina Jolie is an Academy Award-winning actress, filmmaker, and humanitarian")
cursor.execute(sql,data)
data = (2, "Brad", "Pitt", 51, "brad@hollywood.us", "https://s3.amazonaws.com/isat3402021/bp.jpg", "William Bradley Pitt is an American actor and producer known for his portrayal of unconventional characters")
cursor.execute(sql,data)
data = (3, "Snow", "White", 21, "sw@disney.org", "https://s3.amazonaws.com/isat3402021/sw.jpg", "Fleeing from the Evil Queen, Snow White finds refuge with Dopey, Bashful, Grumpy, Sneezy, Happy, Doc and Sleepy. When the palace guards embark on a mission to bring her back, a commoner and his group of woodland bandits band together to protect her.")
cursor.execute(sql,data)
data = (4, "Darth", "Vader", 29, "dv@darkside.me", "https://s3.amazonaws.com/isat3402021/dv.jpg", "Discovered as a slave on Tatooine by Qui-Gon Jinn and Obi-Wan Kenobi, Anakin Skywalker had the potential to become one of the most powerful Jedi ever, and was believed by some to be the prophesied Chosen One who would bring balance to the Force.")
cursor.execute(sql,data)
data = (5, "Taylor", "Swift", 25, "ts@1989.us", "https://s3.amazonaws.com/isat3402021/ts.jpg", "Taylor Alison Swift is a Grammy-winning singer, songwriter, actress, and billionaire who has evolved from country music to pop stardom. Known for her autobiographical lyrics and reinventions, she's one of the best-selling artists of all time and the highest-grossing live music act.")
cursor.execute(sql,data)
data = (6, "Beyonce", "Knowles", 34, "beyonce@jayz.me ", "https://s3.amazonaws.com/isat3402021/bk.jpg", "Beyoncé Giselle Knowles-Carter is an American singer, songwriter, actress, and businesswoman. She's known for her vocals, reinventions, and live performances, and is considered a significant cultural figure of the 21st century.")
cursor.execute(sql,data)
data = (7, "Selena", "Gomez", 23, "selena@hollywood.us", "https://s3.amazonaws.com/isat3402021/sg.jpg", "Selena Marie Gomez is an American actress, singer, producer, songwriter, and businesswoman")
cursor.execute(sql,data)
data = (8, "Stephen", "Curry", 27, "steph@golden.bb", "https://s3.amazonaws.com/isat3402021/sc.jpg", "Wardell Stephen Curry II, also known as Steph Curry, is an American professional basketball player for the Golden State Warriors of the National Basketball Association, where he plays as a point guard")
cursor.execute(sql,data)
data = (9, "Kiera", "Rose", 20, "rose2ka@dukes.jmu.edu", "https://s3.amazonaws.com/isat3402021/kr.jpg", " I was born and raised in New York, during my free time I like to read and go for walks")
cursor.execute(sql,data)
data = (10, "Delia", "Kumar", 21, "kumarda@dukes.jmu.edu", "https://s3.amazonaws.com/isat3402021/kr.jpg", " JMU ISAT student, who likes to read and write")
cursor.execute(sql,data)


conn.commit()
conn.close()